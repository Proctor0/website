<?php

$nameErr = $pwderr = $invalidMesg = "";

if (isset($_POST['submit'])) {

    if ($_POST["usrname"]=="") {
        $nameErr = "Username is required";
      } 
      
      if ($_POST["password"]==null) {
        $pwderr = "Email is required";
      }

    if($_POST['usrname'] != null && $_POST["password"] !=null)
    {
        $array_user = verifyUsers(); //calling this function from SelectUser.php. The function returns an array
        if ($array_user != null) {

      
            if ($array_user[0]['Role']=="student")
            {
                session_start();
                $_SESSION['name'] = $array_user[0]['firstName'];
                $_SESSION['stdID'] = $array_user[0]['userId'];
               
                header("Location: userIndex.php"); 
                exit();
            }

            if ($array_user[0]['Role']=="admin") //if the user is admin, this message will be prompted
            {
                $invalidMesg = "This page is for student login";
            }    
        }
        else{
            $invalidMesg = "Invalid username and password!";
        }
    }
}

?>