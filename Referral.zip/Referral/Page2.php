<html>
  <head>
    <title>PHP Page 2</title>
    <link href="style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
  </head>
    <?PHP
      if (($_POST['member']!=null) and ($_POST['date'])!=null)
      {
        $member = $_POST['member'];
        $since = $_POST['date'];
        $date = strtotime($since);
        $date = date("d F Y", $date); 
        $message = "Hello <strong>".ucfirst($member)."</strong>. You have been a member since <strong>".$date."</strong>";
      }
      else{
        $message = "No input from the previous page!";
      }
    ?>
  <body>
    <p class = "page2Label"><?php echo $message; ?></p>
    
    <div class = "buttons">
      <button onclick="history.back();">Back</button>
      <a href = "index.php" style = "padding-left: 25px;">Back</a>
    </div>
  </body>
</html>