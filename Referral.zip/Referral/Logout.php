<?php 
    if ($_GET['user']=="admin"){
        session_start();
        session_destroy();
        header('Location: YOUR LANDING PAGE!!');
        exit;
    }
    else {
        session_start();
        session_destroy();
        header('Location: YOUR LANDING PAGE!!');
        exit;
    }
?>

