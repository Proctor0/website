<?php include("NavBar.php"); 

$result = $_GET['createUser']; //you can also use $_REQUEST[''] do reseach whats the difference!
?>

<div class="container pb-5">
        <main role="main" class="pb-3">
        <h2>User successful </h2><br>

        <div>
            <?php
                if($result){
                    echo "successfully allowed";
                }
                else{
                    echo "Error";
                }
            ?>
            <div><a href="Index.php">Back</a></div>
        </div>
</div>

<?php
    include("Footer.php"); 
?>
