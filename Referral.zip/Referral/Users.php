<?php require("NavBar.php");?>


<div class="form-group col-md-4">
                        <input class="btn btn-primary" type="submit" value="Delete user" name ="submit">
                   </div>

<?php require("Footer.php");?>