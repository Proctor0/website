<?php require("NavBar.php");

?>
<?php require_once("Login.php");?>
<?include_once("courier.php");?>
	<div class="container bgColor">
        	<main role="main" class="pb-3">
		<h1> Welcome to Blackboard </h1>
		</main>
	</div>

<?php require("Footer.php");?>
