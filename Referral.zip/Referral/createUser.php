<?php require("NavBar.php");
include_once("createUserSQL.php");
$errorfname = $errorlname = $erroruname = $erroruid = $errorpwd = "";
$allFields = "yes";

if (isset($_POST['submit'])){

    if ($_POST['fname']==""){
        $errorfname = "First name is mandatory";
        $allFields = "no";
    }
    if ($_POST['lname']==""){
        $errorlname = "Last name is mandatory";
        $allFields = "no";
    }
    if ($_POST['dobirth']==""){
        $erroruname = "Date_of_birth is mandatory";
        $allFields = "no";
    }
    if ($_POST['mobirth']==""){
        $erroruid = "Month_of_birth is mandatory";
        $allFields = "no";
    }
    if ($_POST['pcode']==""){
        $errorpwd = "Postcode is mandatory";
        $allFields = "no";
    }
    if ($_POST['cnumber']==""){
        $errorpwd = "Contact_number is mandatory";
        $allFields = "no";
    }

    if($allFields == "yes")
    {
        $createUser = createUser();
        header('Location: userCreationSummary.php?createUser='.$createUser);
    }
}

?>
<div class="container pb-5">
        <main role="main" class="pb-3">
            <div class="row">
            <div class="col-6">
                <form method="post">
                   <div class="form-group col-md-6">
                        <label class="control-label labelFont">First Name</label>
                        <input class="form-control" type="text" name = "fname">
                        <span class="text-danger"><?php echo $errorfname; ?></span>
                   </div>
 
                   <div class="form-group col-md-6">
                        <label class="control-label labelFont">Last Name</label>
                        <input class="form-control" type="text" name = "lname">
                        <span class="text-danger"><?php echo $errorfname; ?></span>
                   </div>

                   <div class="form-group col-md-6">
                        <label class="control-label labelFont">Date of birth</label>
                        <input class="form-control" type="text" name = "dobirth">
                        <span class="text-danger"><?php echo $errorfname; ?></span>
                   </div>

                   <div class="form-group col-md-6">
                        <label class="control-label labelFont">Month of birth</label>
                        <input class="form-control" type="text" name = "mobirth">
                        <span class="text-danger"><?php echo $errorfname; ?></span>
                   </div>

                   <div class="form-group col-md-6">
                        <label class="control-label labelFont">Postcode</label>
                        <input class="form-control" type="text" name = "pcode">
                        <span class="text-danger"><?php echo $errorfname; ?></span>
                   </div>

                   <div class="form-group col-md-8">
                        <label class="control-label labelFont">Contact Number</label>
                        <input class="form-control" type="number    " name = "cnumber">
                        <span class="text-danger"><?php echo $errorfname; ?></span>
                   </div>
 
                   <div class="form-group col-md-4">
                        <input class="btn btn-primary" type="submit" value="Create User" name ="submit">
                   </div>
                   <div>
                       <a href="userPdf.php" target="_blank">Generate PDF</a>
                    </div>

                </form>
            </div>
        </div>

   	  </main>
</div>
<?php require("Footer.php");?>